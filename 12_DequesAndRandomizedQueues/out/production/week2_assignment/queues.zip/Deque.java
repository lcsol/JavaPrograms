import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item> {
    private int size;
    private Node sentinelHead, sentinelTail, first, last;

    private class Node {
        Item item;
        Node previous;
        Node next;
    }
    // construct an empty deque
    public Deque() {
        sentinelHead = new Node();
        sentinelTail = new Node();
        first = sentinelHead.next;
        last = sentinelTail.previous;
        size = 0;
    }
    // is the deque empty?
    public boolean isEmpty() {
        return first == null;
    }
    // return the number of items on the deque
    public int size() {
        return size;
    }
    // add the item to the front
    public void addFirst(Item item) {
        if (item == null) throw new IllegalArgumentException();
        Node oldFirst = first;
        first = new Node();
        first.item = item;
        first.previous = sentinelHead;
        first.next = oldFirst;
        if (oldFirst != null) oldFirst.previous = first;
        size++;
    }
    // add the item to the end
    public void addLast(Item item) {
        if (item == null) throw new IllegalArgumentException();
        Node oldLast = last;
        Node last = new Node();
        last.item = item;
        last.previous = oldLast;
        last.next = sentinelTail;
        if (oldLast != null) oldLast.next = last;
        size++;
    }
    // remove and return the item from the front
    public Item removeFirst() {
        if (isEmpty()) throw new NoSuchElementException();
        Item item = first.item;
        first = first.next;
        first.previous = sentinelHead;
        size--;
        return item;
    }
    // remove and return the item from the end
    public Item removeLast() {
        if (isEmpty()) throw new NoSuchElementException();
        Item item = last.item;
        last = last.previous;
        last.next = sentinelTail;
        sentinelTail.previous = last;
        size--;
        return item;
    }
    // return an iterator over items in order from front to end
    public Iterator<Item> iterator() {
        return new ListIterator();
    }
    private class ListIterator implements Iterator<Item> {
        private Node current = first;
        public boolean hasNext() {return current != null;}
        public void remove() {throw new UnsupportedOperationException();}
        public Item next() {
            if (!hasNext()) throw new NoSuchElementException();
            Item item = current.item;
            current = current.next;
            return item;
        }
    }

//    public static void main(String[] args) {
//        Deque<String> deque = new Deque<>();
//        deque.addFirst("first");
//        deque.addFirst("newFirst");
//        deque.addLast("last");
//        deque.addLast("newLast");
//        //StdOut.println(deque.iterator());
//        deque.removeFirst();
//        deque.removeLast();
//    }
}
