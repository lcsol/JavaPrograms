import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;

public class FastCollinearPoints {
    private final ArrayList<LineSegment> seg;
    private int number;
    private ArrayList<Double> slopeList;
    // finds all line segments containing 4 or more points
    public FastCollinearPoints(Point[] points) {
        if (points == null || Arrays.asList(points).contains(null)) throw new IllegalArgumentException();
        checkDuplicate(points);

        seg = new ArrayList<>();
        slopeList = new ArrayList<>();

        Point[] copy = Arrays.copyOf(points, points.length);

        for (Point origin : copy) {

            Arrays.sort(copy, origin.slopeOrder());

            int lo = 1, hi = 1;
            while (lo < copy.length && hi < copy.length) {
                while (origin.slopeOrder().compare(copy[lo], copy[hi]) == 0) {
                    hi++;
                }

                if (hi - lo >= 3) {
                    Arrays.sort(copy, lo, hi);
                    Point start = (origin.compareTo(copy[lo]) < 0) ? origin : copy[lo];
                    Point end = (origin.compareTo(copy[hi - 1]) > 0) ? origin : copy[hi - 1];
                    LineSegment line = new LineSegment(start, end);
                    double slope = start.slopeTo(end);
                    if (!slopeList.contains(slope)) {
                        seg.add(line);
                        slopeList.add(slope);
                        number++;
                    }
                }
                lo = hi;
            }
        }

    }

    private void checkDuplicate(Point[] p) {
        for (int i = 0; i < p.length; i++) {
            for (int j = i + 1; j < p.length; j++) {
                if (p[i].compareTo(p[j]) == 0) throw new IllegalArgumentException();
            }
        }
    }
    // the number of line segments
    public int numberOfSegments() {
        return number;
    }
    // the line segments
    public LineSegment[] segments() {
        return seg.toArray(new LineSegment[number]);
    }

    public static void main(String[] args) {

        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }
}